# Testdata for singular alignment segment
x,y coordinates are calculated along the segment starting in 0,0 into the direction of positive x-axis in stated stepsize.
Parametervalues (e.g. curvature, gradient, cant/cantangle) are calculated along the segment in stated stepsize.
## Segment parameters
* Segmenttype: CLOTHOID (linear change of curvature)
* Total length of segment: 72
* Length Unit: Meter
* Startradius: straight line
* Endradius: -467 (right leaning)
* Startcurvature ( 1 / Startradius): 0
* Endcurvature ( 1 / Endradius): -0.0021413276231263384
* Increments (stepsize in Meter): 1
## Standardplots
<img src="./Clothoide_72_inf_-467_1_Meter.png">
