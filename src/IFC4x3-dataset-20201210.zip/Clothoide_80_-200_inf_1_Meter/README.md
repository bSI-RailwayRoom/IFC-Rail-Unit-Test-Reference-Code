# Testdata for singular alignment segment
x,y coordinates are calculated along the segment starting in 0,0 into the direction of positive x-axis in stated stepsize.
Parametervalues (e.g. curvature, gradient, cant/cantangle) are calculated along the segment in stated stepsize.
## Segment parameters
* Segmenttype: CLOTHOID (linear change of curvature)
* Total length of segment: 80
* Length Unit: Meter
* Startradius: -200 (right leaning)
* Endradius: straight line
* Startcurvature ( 1 / Startradius): -0.005
* Endcurvature ( 1 / Endradius): 0
* Increments (stepsize in Meter): 1
## Parameters for Taylor expansion series approximation
* Length for Taylorformula: 80
* Startstation along Clothoidcurve: -80
* Endstation along Clothoidcurve: 0
## Standardplots
<img src="./Clothoide_80_-200_inf_1_Meter.png">
