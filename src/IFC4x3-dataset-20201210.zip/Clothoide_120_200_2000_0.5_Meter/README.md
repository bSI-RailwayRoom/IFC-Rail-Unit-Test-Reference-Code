# Testdata for singular alignment segment
x,y coordinates are calculated along the segment starting in 0,0 into the direction of positive x-axis in stated stepsize.
Parametervalues (e.g. curvature, gradient, cant/cantangle) are calculated along the segment in stated stepsize.
## Segment parameters
* Segmenttype: CLOTHOID (linear change of curvature)
* Total length of segment: 120
* Length Unit: Meter
* Startradius: 200 (left leaning)
* Endradius: 2000 (left leaning)
* Startcurvature ( 1 / Startradius): 0.005
* Endcurvature ( 1 / Endradius): 0.0005
* Increments (stepsize in Meter): 0.5
## Standardplots
<img src="./Clothoide_120_200_2000_0.5_Meter.png">
