#pragma once

#include "generic.h"
#include "mathematics.h"
#include "ifcpolynomialcurve.h"
#include "ifcproductdefinitionshape.h"


static  inline  int_t   SegmentCount__alignmentVertical(
                                int_t   model,
                                int_t   ifcVerticalAlignmentInstance
                            )
{
	int_t	* aggrSegments = nullptr;

    sdaiGetAttrBN(ifcVerticalAlignmentInstance, "Segments", sdaiAGGR, &aggrSegments);

    return  sdaiGetMemberCount(aggrSegments);
}

static  inline  int_t   CreateGradientCurve__alignmentVertical(
                                int_t   model,
                                int_t   ifcVerticalAlignmentInstance,
                                double  startDistAlongHorizontalAlignment
                            )
{
    double  epsilon = 0.0000001;

	int_t	ifcGradientCurveInstance = sdaiCreateInstanceBN(model, "IFCGRADIENTCURVE"),
            * aggrCurveSegment = sdaiCreateAggrBN(ifcGradientCurveInstance, "Segments"),
        	* aggrSegments = nullptr;

    char    selfIntersect[2] = "F";
    sdaiPutAttrBN(ifcGradientCurveInstance, "SelfIntersect", sdaiENUM, (void*) selfIntersect);

    int_t   noSegmentInstances =
                GetAlignmentSegments(
                        model,
                        ifcVerticalAlignmentInstance,
                        nullptr
                    );

    if (noSegmentInstances) {
        int_t   * segmentInstances = new int_t[noSegmentInstances];

        GetAlignmentSegments(
                model,
                ifcVerticalAlignmentInstance,
                segmentInstances
            );

        for (int_t i = 0; i < noSegmentInstances; i++) {
            int_t   ifcAlignmentSegmentInstance = segmentInstances[i];
            assert(sdaiGetInstanceType(ifcAlignmentSegmentInstance) == sdaiGetEntity(model, "IFCALIGNMENTSEGMENT"));

#ifdef _DEBUG
            int_t   expressID = internalGetP21Line(ifcAlignmentSegmentInstance);
#endif // _DEBUG

            int_t   ifcAlignmentVerticalSegmentInstance = 0;
            sdaiGetAttrBN(ifcAlignmentSegmentInstance, "DesignParameters", sdaiINSTANCE, (void*) &ifcAlignmentVerticalSegmentInstance);
            assert(sdaiGetInstanceType(ifcAlignmentVerticalSegmentInstance) == sdaiGetEntity(model, "IFCALIGNMENTVERTICALSEGMENT"));

            int_t   expressLine = internalGetP21Line(ifcAlignmentVerticalSegmentInstance);

            {
                int_t   ifcCurveSegmentInstance = sdaiCreateInstanceBN(model, "IFCCURVESEGMENT");

                //
                //  Add geometry for Ifc...Alignment...
                //
                sdaiPutAttrBN(
                        ifcAlignmentSegmentInstance,
                        "Representation",
                        sdaiINSTANCE,
                        (void*) CreateProductDefinitionShape(
                                        model,
                                        ifcCurveSegmentInstance
                                    )
                    );

                //
                //  ENTITY IfcAlignmentVerticalSegment
                //      StartDistAlong      IfcLengthMeasure
                //      HorizontalLength    IfcPositiveLengthMeasure
                //      StartHeight         IfcLengthMeasure
                //      StartGradient       IfcLengthMeasure
                //      EndGradient         IfcLengthMeasure
                //      RadiusOfCurvature   OPTIONAL IfcPositiveLengthMeasure
                //      PredefinedType      IfcAlignmentVerticalSegmentTypeEnum
                //  END_ENTITY
                //

                //
                //  StartDistAlong
                //
                double  startDistAlong = 0.;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "StartDistAlong", sdaiREAL, &startDistAlong);

                //
                //  HorizontalLength
                //
                double  horizontalLength = 0.;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "HorizontalLength", sdaiREAL, &horizontalLength);

                //
                //  StartHeight
                //
                double  startHeight = 0.;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "StartHeight", sdaiREAL, &startHeight);

                //
                //  StartGradient
                //
                double  startGradient__ = 0.;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "StartGradient", sdaiREAL, &startGradient__);

                //
                //  EndGradient
                //
                double  endGradient__ = 0.;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "EndGradient", sdaiREAL, &endGradient__);

                //
                //  RadiusOfCurvature
                //
                double  radiusOfCurvature = 0.;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "RadiusOfCurvature", sdaiREAL, &radiusOfCurvature);

                //
                //  Transition
                //
                if (i == noSegmentInstances - 1) {
                    char    transitionCode[14] = "DISCONTINUOUS";
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "Transition", sdaiENUM, (void*) transitionCode);
                }
                else {
                    char    transitionCode[30] = "CONTSAMEGRADIENTSAMECURVATURE";
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "Transition", sdaiENUM, (void*) transitionCode);
                }

                VECTOR2 refDirection = {
                                1.,
                                startGradient__
                            },
                        location = {
                                startDistAlong - startDistAlongHorizontalAlignment,
                                startHeight
                            };
                Vec2Normalize(&refDirection);
                sdaiPutAttrBN(ifcCurveSegmentInstance, "Placement", sdaiINSTANCE, (void*) CreateAxis2Placement2D(model, &refDirection, &location));

                if ((horizontalLength == 0.) &&
                    (i == noSegmentInstances - 1)) {
                    sdaiPutAttrBN(ifcGradientCurveInstance, "EndPoint", sdaiINSTANCE, (void*) CreateAxis2Placement2D(model, &refDirection, &location));
                }
                else {
                    assert(horizontalLength > 0.);
                }

                //
                //  Parse the individual segments
                //      CONSTANTGRADIENT
                //      CIRCULARARC
                //      PARABOLICARC
                //      CLOTHOID
                //
                char    * predefinedType = nullptr;
                sdaiGetAttrBN(ifcAlignmentVerticalSegmentInstance, "PredefinedType", sdaiENUM, &predefinedType);
                if (equals(predefinedType, (char*) "CIRCULARARC")) {
                    double  startAngle = std::atan(startGradient__),
                            endAngle = std::atan(endGradient__);
                    assert(startAngle > -Pi && startAngle < Pi && endAngle > -Pi && endAngle < Pi);

                    double  radius;
                    VECTOR2 origin;
                    if (startAngle < endAngle) {
                        assert(radiusOfCurvature > 0.);
                        //
                        //  Ox = -sin( startAngle ) * radius         Ox = horizontalLength - sin( endAngle ) * radius
                        //  Oy = cos( startAngle ) * radius          Oy = offsetY + cos( endAngle ) * radius
                        //
                        //  horizontalLength = (sin( endAngle ) - sin( startAngle )) * radius
                        //  radius = horizontalLength / (sin( endAngle ) - sin( startAngle ));
                        //
                        radius = horizontalLength / (sin(endAngle) - sin(startAngle));
                        assert(radius > 0. && std::fabs(radius - radiusOfCurvature) < 0.001);

                        //
                        //  offsetY = (cos( startAngle ) - cos( endAngle )) * radius;
                        //
                        double  offsetY = (cos(startAngle) - cos(endAngle)) * radius;

                        origin.x = -sin(startAngle) * radius;
                        origin.y = cos(startAngle) * radius;

                        assert(std::fabs(origin.x - (horizontalLength - sin(endAngle) * radius)) < epsilon);
                        assert(std::fabs(origin.y - (offsetY + cos(endAngle) * radius)) < epsilon);

                        startAngle += 3. * Pi / 2.;
                        endAngle += 3. * Pi / 2.;

                        origin.x = -cos(startAngle) * radius;
                        origin.y = -sin(startAngle) * radius;
                    }
                    else {
                        assert(startAngle > endAngle);
                        assert(radiusOfCurvature < 0.);
                        //
                        //  Ox = sin( startAngle ) * radius         Ox = horizontalLength + sin( endAngle ) * radius
                        //  Oy = -cos( startAngle ) * radius        Oy = offsetY - cos( endAngle ) * radius
                        //
                        //  horizontalLength = (sin( startAngle ) - sin( endAngle )) * radius
                        //  radius = horizontalLength / (sin( startAngle ) - sin( endAngle ));
                        //
                        radius = horizontalLength / (sin(startAngle) - sin(endAngle));
                        assert(radius > 0. && std::fabs(radius + radiusOfCurvature) < 0.001);
 
                        //
                        //  offsetY = (cos( endAngle ) - cos( startAngle )) * radius;
                        //
                        double  offsetY = (cos(endAngle) - cos(startAngle)) * radius;

                        origin.x = sin(startAngle) * radius;
                        origin.y = -cos(startAngle) * radius;

                        assert(std::fabs(origin.x - (horizontalLength + sin(endAngle) * radius)) < epsilon);
                        assert(std::fabs(origin.y - (offsetY - cos(endAngle) * radius)) < epsilon);

                        startAngle += Pi / 2.;
                        endAngle += Pi / 2.;

                        origin.x = -cos(startAngle) * radius;
                        origin.y = -sin(startAngle) * radius;
                    }

                    int_t   ifcCircleInstance = CreateCircle__woRotation(model, radius);
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "ParentCurve", sdaiINSTANCE, (void*) ifcCircleInstance);

                    //
                    //  SegmentStart
                    //
                    void   * segmentStartADB = sdaiCreateADB(sdaiREAL, &startAngle);
                    sdaiPutADBTypePath(segmentStartADB, 1, "IFCPARAMETERVALUE");
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentStart", sdaiADB, (void*) segmentStartADB);

                    double  segmentLengthAsParameter = endAngle - startAngle;
                    assert(std::fabs(segmentLengthAsParameter * radius) > horizontalLength);
                    //
                    //  SegmentLength
                    //
                    void   * segmentLengthADB = sdaiCreateADB(sdaiREAL, &segmentLengthAsParameter);
                    sdaiPutADBTypePath(segmentLengthADB, 1, "IFCPARAMETERVALUE");
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentLength", sdaiADB, (void*) segmentLengthADB);
                }
                else if (equals(predefinedType, (char*) "CLOTHOID")) {
    assert(false);
    //                int_t   ifcClothoidInstance = CreateClothoid(model, startRadiusOfCurvature, endRadiusOfCurvature, segmentLength, ifcCurveSegmentInstance, &segmentLength);
    //                sdaiPutAttrBN(ifcCurveSegmentInstance, "ParentCurve", sdaiINSTANCE, (void*) ifcClothoidInstance);
                }
                else if (equals(predefinedType, (char*) "CONSTANTGRADIENT")) {
                    VECTOR2 orientation = {
                                    1.,
                                    0.
                                };
                    int_t   ifcLineInstance = CreateLine(model, &orientation);
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "ParentCurve", sdaiINSTANCE, (void*) ifcLineInstance);

                    //
                    //  SegmentStart
                    //
                    double  offset = 0.;
                    void   * segmentStartADB = sdaiCreateADB(sdaiREAL, &offset);
                    sdaiPutADBTypePath(segmentStartADB, 1, "IFCNONNEGATIVELENGTHMEASURE");
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentStart", sdaiADB, (void*) segmentStartADB);

                    double  segmentLength = horizontalLength * std::sqrt(1. + startGradient__ * startGradient__);

                    //
                    //  SegmentLength
                    //
                    void   * segmentLengthADB = sdaiCreateADB(sdaiREAL, &segmentLength);
                    sdaiPutADBTypePath(segmentLengthADB, 1, "IFCPARAMETERVALUE");
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentLength", sdaiADB, (void*) segmentLengthADB);
                }
                else {
                    assert(equals(predefinedType, (char*) "PARABOLICARC"));

                    //
                    //  radiusOfCurvature is here the ParabolaConstant (minimum radius at its apex)
                    //
                    
                    //
                    //  g1 = (s1 - s0) / R + g0     =>      (s1 - s0) = (g1 - g0) * R
                    //  y1 = (s1 - s0) * (g1 + g0) / 2 + y0
                    //
                    //  horizontalLength = s0 - s1
                    //
                    double  offset,
                            g1 = startGradient__,
                            g0 = endGradient__;
                    if (g1 - g0) {
                        double  R = horizontalLength / (g1 - g0);
                        assert(R == radiusOfCurvature);

                        double  y0 = startHeight,
                                y1 = y0 + horizontalLength * (g1 + g0) / 2.;

                        offset = g0 * R;
                    }
                    else {
                        offset = 0.;
                    }

                    double  pCoefficientsX[] = { 0., 1. },
                            pCoefficientsY[] = { 0., 0., radiusOfCurvature };
                    int_t   ifcPolygonalCurveInstance =
                                CreatePolynomialCurve__woRotation(
                                        model,
                                        pCoefficientsX, sizeof(pCoefficientsX) / sizeof(double),
                                        pCoefficientsY, sizeof(pCoefficientsY) / sizeof(double),
                                        nullptr, 0
                                    );

                    //
                    //  SegmentStart
                    //
                    void   * segmentStartADB = sdaiCreateADB(sdaiREAL, &offset);
                    sdaiPutADBTypePath(segmentStartADB, 1, "IFCPARAMETERVALUE");
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentStart", sdaiADB, (void*) segmentStartADB);

                    double  segmentLength = horizontalLength;

                    //
                    //  SegmentLength
                    //
                    void   * segmentLengthADB = sdaiCreateADB(sdaiREAL, &segmentLength);
                    sdaiPutADBTypePath(segmentLengthADB, 1, "IFCPARAMETERVALUE");
                    sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentLength", sdaiADB, (void*) segmentLengthADB);
                }

                sdaiAppend((int_t) aggrCurveSegment, sdaiINSTANCE, (void*) ifcCurveSegmentInstance);
            }
        }

        delete[] segmentInstances;
    }

    return  ifcGradientCurveInstance;
}

static  inline  int_t   GetAlignmentVertical(
                                int_t   model,
                                int_t   ifcAlignmentInstance
                            )
{
    int_t   ifcAlignmentVerticalInstance = 0;

    {
	    int_t	* aggrIfcRelAggregates = nullptr, noAggrIfcRelAggregates;
        sdaiGetAttrBN(ifcAlignmentInstance, "IsNestedBy", sdaiAGGR, &aggrIfcRelAggregates);
        noAggrIfcRelAggregates = sdaiGetMemberCount(aggrIfcRelAggregates);
        for (int_t i = 0; i < noAggrIfcRelAggregates; i++) {
            int_t   ifcRelAggregatesInstance = 0;
            engiGetAggrElement(aggrIfcRelAggregates, i, sdaiINSTANCE, &ifcRelAggregatesInstance);

    	    int_t	* aggrIfcObjectDefinition = nullptr, noAggrIfcObjectDefinition;
            sdaiGetAttrBN(ifcRelAggregatesInstance, "RelatedObjects", sdaiAGGR, &aggrIfcObjectDefinition);
            noAggrIfcObjectDefinition = sdaiGetMemberCount(aggrIfcObjectDefinition);
            for (int_t j = 0; j < noAggrIfcObjectDefinition; j++) {
                int_t   ifcObjectDefinitionInstance = 0;
                engiGetAggrElement(aggrIfcObjectDefinition, j, sdaiINSTANCE, &ifcObjectDefinitionInstance);

                if (sdaiGetInstanceType(ifcObjectDefinitionInstance) == sdaiGetEntity(model, "IFCALIGNMENTVERTICAL")) {
                    assert(ifcAlignmentVerticalInstance == 0);
                    ifcAlignmentVerticalInstance = ifcObjectDefinitionInstance;
                }
            }
        }
    }

    if (ifcAlignmentVerticalInstance == 0) {
	    int_t	* aggrIfcRelAggregates = nullptr, noAggrIfcRelAggregates;
        sdaiGetAttrBN(ifcAlignmentInstance, "IsDecomposedBy", sdaiAGGR, &aggrIfcRelAggregates);
        noAggrIfcRelAggregates = sdaiGetMemberCount(aggrIfcRelAggregates);
        for (int_t i = 0; i < noAggrIfcRelAggregates; i++) {
            int_t   ifcRelAggregatesInstance = 0;
            engiGetAggrElement(aggrIfcRelAggregates, i, sdaiINSTANCE, &ifcRelAggregatesInstance);

    	    int_t	* aggrIfcObjectDefinition = nullptr, noAggrIfcObjectDefinition;
            sdaiGetAttrBN(ifcRelAggregatesInstance, "RelatedObjects", sdaiAGGR, &aggrIfcObjectDefinition);
            noAggrIfcObjectDefinition = sdaiGetMemberCount(aggrIfcObjectDefinition);
            for (int_t j = 0; j < noAggrIfcObjectDefinition; j++) {
                int_t   ifcObjectDefinitionInstance = 0;
                engiGetAggrElement(aggrIfcObjectDefinition, j, sdaiINSTANCE, &ifcObjectDefinitionInstance);

                if (sdaiGetInstanceType(ifcObjectDefinitionInstance) == sdaiGetEntity(model, "IFCALIGNMENTVERTICAL")) {
                    assert(ifcAlignmentVerticalInstance == 0);
                    ifcAlignmentVerticalInstance = ifcObjectDefinitionInstance;

//                    assert(false);  //  should be a nested relations
                }
            }
        }
    }

    return  ifcAlignmentVerticalInstance;
}
