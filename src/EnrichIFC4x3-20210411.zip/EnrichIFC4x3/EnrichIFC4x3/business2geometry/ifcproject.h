#pragma once

#include "ifcunitassignment.h"


static	inline	double  GetPlaneAngleUnitConversionFactor(
                                int_t   model
                            )
{
    int_t   * ifcProjectInstances = sdaiGetEntityExtentBN(model, "IFCPROJECT"),
            noIfcProjectInstances = sdaiGetMemberCount(ifcProjectInstances);
    if (noIfcProjectInstances) {
        assert(noIfcProjectInstances == 1);

        int_t   ifcProjectInstance = 0;
        engiGetAggrElement(ifcProjectInstances, 0, sdaiINSTANCE, &ifcProjectInstance);

        int_t   ifcUnitAssignmentInstance = 0;
        sdaiGetAttrBN(ifcProjectInstance, "UnitsInContext", sdaiINSTANCE, &ifcUnitAssignmentInstance);

        return  GetPlaneAngleUnitConversionFactor(
                        model,
                        ifcUnitAssignmentInstance
                    );
    }

    assert(false);
    return	1.;
}
