#pragma once

#include "ifcalignmentcant.h"
#include "ifcalignmenthorizontal.h"
#include "ifcalignmentvertical.h"
#include "ifcproject.h"
#include "ifcproductdefinitionshape.h"


static  inline  void    AlignmentGenerateGeometry(
                                int_t   model,
                                int_t   ifcAlignmentInstance
                            )
{
    bool    hasAlignmentHorizontal =
                (GetAlignmentHorizontal(
                        model,
                        ifcAlignmentInstance
                    )) ? true : false,
            hasAlignmentVertical =
                (GetAlignmentVertical(
                        model,
                        ifcAlignmentInstance
                    )) ? true : false,
            hasAlignmentCant =
                (GetAlignmentCant(
                        model,
                        ifcAlignmentInstance
                    )) ? true : false;

    assert(hasAlignmentHorizontal);

    int_t   ifcRepresentationItem_compositeCurveInstance =
                CreateCompositeCurve__alignmentHorizontal(
                        model,
                        GetAlignmentHorizontal(
                                model,
                                ifcAlignmentInstance
                            ),
                        GetPlaneAngleUnitConversionFactor(
                                model
                            )
                    ),
            ifcRepresentationItem;

    if (hasAlignmentVertical || hasAlignmentCant) {
        double  startDistAlongHorizontalAlignment = 0.;
        
        sdaiGetAttrBN(
                GetAlignmentHorizontal(
                        model,
                        ifcAlignmentInstance
                    ),
                "StartDistAlong",
                sdaiREAL,
                &startDistAlongHorizontalAlignment
            );

        int_t   ifcRepresentationItem_gradientCurveInstance =
                    CreateGradientCurve__alignmentVertical(
                            model,
                            GetAlignmentVertical(
                                    model,
                                    ifcAlignmentInstance
                                ),
                            startDistAlongHorizontalAlignment
                        );

        sdaiPutAttrBN(
                ifcRepresentationItem_gradientCurveInstance,
                "BaseCurve",
                sdaiINSTANCE,
                (void*) ifcRepresentationItem_compositeCurveInstance
            );

        //
        //  Add geometry for IfcVerticalAlignment
        //
        sdaiPutAttrBN(
                GetAlignmentVertical(
                        model,
                        ifcAlignmentInstance
                    ),
                "Representation",
                sdaiINSTANCE,
                (void*) CreateProductDefinitionShape(
                                model,
                                ifcRepresentationItem_gradientCurveInstance
                            )
            );

        if (hasAlignmentCant) {
            int_t   ifcRepresentationItem_segmentedReferenceCurveInstance =
                        CreateSegmentedReferenceCurve__alignmentCant(
                                model,
                                GetAlignmentCant(
                                        model,
                                        ifcAlignmentInstance
                                    ),
                                startDistAlongHorizontalAlignment
                            );

            sdaiPutAttrBN(
                    ifcRepresentationItem_segmentedReferenceCurveInstance,
                    "BaseCurve",
                    sdaiINSTANCE,
                    (void*) ifcRepresentationItem_gradientCurveInstance
                );


            //
            //  Add geometry for IfcCantAlignment
            //
            sdaiPutAttrBN(
                    GetAlignmentCant(
                            model,
                            ifcAlignmentInstance
                        ),
                    "Representation",
                    sdaiINSTANCE,
                    (void*) CreateProductDefinitionShape(
                                    model,
                                    ifcRepresentationItem_segmentedReferenceCurveInstance
                                )
                );

            ifcRepresentationItem = ifcRepresentationItem_segmentedReferenceCurveInstance;
        }
        else {
            ifcRepresentationItem = ifcRepresentationItem_gradientCurveInstance;
        }
    }
    else {
        ifcRepresentationItem = ifcRepresentationItem_compositeCurveInstance;
    }

    //
    //  Add geometry for IfcAlignment
    //
    sdaiPutAttrBN(
            ifcAlignmentInstance,
            "Representation",
            sdaiINSTANCE,
            (void*) CreateProductDefinitionShape(
                            model,
                            ifcRepresentationItem
                        )
        );

    //
    //  Add geometry for IfcHorizontalAlignment
    //
    sdaiPutAttrBN(
            GetAlignmentHorizontal(
                    model,
                    ifcAlignmentInstance
                ),
            "Representation",
            sdaiINSTANCE,
            (void*) CreateProductDefinitionShape(
                            model,
                            ifcRepresentationItem_compositeCurveInstance
                        )
        );
}
