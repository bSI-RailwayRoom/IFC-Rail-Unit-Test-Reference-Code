#pragma once

#include "ifccartesianpoint.h"
#include "ifcdirection.h"


static	inline	int_t	CreateAxis2Placement3D(
								int_t   model
							)
{
	int_t	ifcAxis2Placement3DInstance;

    ifcAxis2Placement3DInstance = sdaiCreateInstanceBN(model,(char*) "IFCAXIS2PLACEMENT3D");

	VECTOR3	vecLocation = { 0., 0., 0. };
	sdaiPutAttrBN(ifcAxis2Placement3DInstance, "Location", sdaiINSTANCE, (void*) CreateCartesianPoint3D(model, &vecLocation));

	assert(ifcAxis2Placement3DInstance);

	return	ifcAxis2Placement3DInstance;
}

static	inline	int_t	CreateAxis2Placement3D(
								int_t   model,
								MATRIX  * matrix
							)
{
	int_t	ifcAxis2Placement3DInstance;

    ifcAxis2Placement3DInstance = sdaiCreateInstanceBN(model,(char*) "IFCAXIS2PLACEMENT3D");

	sdaiPutAttrBN(ifcAxis2Placement3DInstance, "Location", sdaiINSTANCE, (void*) CreateCartesianPoint3D(model, (VECTOR3*) &matrix->_41));
	sdaiPutAttrBN(ifcAxis2Placement3DInstance, "Axis", sdaiINSTANCE, (void*) CreateDirection_3D(model, (VECTOR3*) &matrix->_31));
	sdaiPutAttrBN(ifcAxis2Placement3DInstance, "RefDirection", sdaiINSTANCE, (void* ) CreateDirection_3D(model, (VECTOR3*) &matrix->_11));

	assert(ifcAxis2Placement3DInstance);

	return	ifcAxis2Placement3DInstance;
}
