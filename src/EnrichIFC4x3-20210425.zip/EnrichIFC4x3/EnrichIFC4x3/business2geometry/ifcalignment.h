#pragma once


#include "ifcalignmentcant.h"
#include "ifcalignmenthorizontal.h"
#include "ifcalignmentvertical.h"
#include "ifccartesianpoint.h"
#include "ifcderivedprofiledef.h"
#include "ifcfixedreferencesweptareasolid.h"
#include "ifcproject.h"
#include "ifcproductdefinitionshape.h"


static  inline  void    AlignmentGenerateGeometry(
                                int_t   model,
                                int_t   ifcAlignmentInstance
                            )
{
    bool    hasAlignmentHorizontal =
                (___GetAlignmentHorizontal(
                        model,
                        ifcAlignmentInstance
                    )) ? true : false,
            hasAlignmentVertical =
                (___GetAlignmentVertical(
                        model,
                        ifcAlignmentInstance
                    )) ? true : false,
            hasAlignmentCant =
                (___GetAlignmentCant(
                        model,
                        ifcAlignmentInstance
                    )) ? true : false;

    assert(hasAlignmentHorizontal);

    int_t   ifcRepresentationItem_compositeCurveInstance =
                ___CreateCompositeCurve__alignmentHorizontal(
                        model,
                        ___GetAlignmentHorizontal(
                                model,
                                ifcAlignmentInstance
                            ),
                        ___GetPlaneAngleUnitConversionFactor(
                                model
                            )
                    ),
            ifcRepresentationItem;

    if (hasAlignmentVertical || hasAlignmentCant) {
        double  startDistAlongHorizontalAlignment = 0.;
        
        sdaiGetAttrBN(
                ___GetAlignmentHorizontal(
                        model,
                        ifcAlignmentInstance
                    ),
                "StartDistAlong",
                sdaiREAL,
                &startDistAlongHorizontalAlignment
            );

        int_t   ifcRepresentationItem_gradientCurveInstance =
                    ___CreateGradientCurve__alignmentVertical(
                            model,
                            ___GetAlignmentVertical(
                                    model,
                                    ifcAlignmentInstance
                                ),
                            startDistAlongHorizontalAlignment
                        );

        sdaiPutAttrBN(
                ifcRepresentationItem_gradientCurveInstance,
                "BaseCurve",
                sdaiINSTANCE,
                (void*) ifcRepresentationItem_compositeCurveInstance
            );

        //
        //  Add geometry for IfcVerticalAlignment
        //
        sdaiPutAttrBN(
                ___GetAlignmentVertical(
                        model,
                        ifcAlignmentInstance
                    ),
                "Representation",
                sdaiINSTANCE,
                (void*) ___CreateProductDefinitionShape(
                                model,
                                ifcRepresentationItem_gradientCurveInstance
                            )
            );

        if (hasAlignmentCant) {
            int_t   ifcRepresentationItem_segmentedReferenceCurveInstance =
                        ___CreateSegmentedReferenceCurve__alignmentCant(
                                model,
                                ___GetAlignmentCant(
                                        model,
                                        ifcAlignmentInstance
                                    ),
                                startDistAlongHorizontalAlignment
                            );

            sdaiPutAttrBN(
                    ifcRepresentationItem_segmentedReferenceCurveInstance,
                    "BaseCurve",
                    sdaiINSTANCE,
                    (void*) ifcRepresentationItem_gradientCurveInstance
                );


            //
            //  Add geometry for IfcCantAlignment
            //
            sdaiPutAttrBN(
                    ___GetAlignmentCant(
                            model,
                            ifcAlignmentInstance
                        ),
                    "Representation",
                    sdaiINSTANCE,
                    (void*) ___CreateProductDefinitionShape(
                                    model,
                                    ifcRepresentationItem_segmentedReferenceCurveInstance
                                )
                );

            ifcRepresentationItem = ifcRepresentationItem_segmentedReferenceCurveInstance;
        }
        else {
            ifcRepresentationItem = ifcRepresentationItem_gradientCurveInstance;
        }
    }
    else {
        ifcRepresentationItem = ifcRepresentationItem_compositeCurveInstance;
    }

    //
    //  Add geometry for IfcAlignment
    //
    sdaiPutAttrBN(
            ifcAlignmentInstance,
            "Representation",
            sdaiINSTANCE,
            (void*) ___CreateProductDefinitionShape(
                            model,
                            ifcRepresentationItem
                        )
        );

    //
    //  Add geometry for IfcHorizontalAlignment
    //
    sdaiPutAttrBN(
            ___GetAlignmentHorizontal(
                    model,
                    ifcAlignmentInstance
                ),
            "Representation",
            sdaiINSTANCE,
            (void*) ___CreateProductDefinitionShape(
                            model,
                            ifcRepresentationItem_compositeCurveInstance
                        )
        );
}

static  inline  int_t    AlignmentGenerateSweep(
                                int_t   model,
                                int_t   ifcAlignmentInstance,
                                int_t   ifcProfileInstance,
                                int_t   ifcProductInstance
                            )
{
    int_t   ifcFixedReferenceSweptAreaSolidInstance =
                (___GetAlignmentCant(
                        model,
                        ifcAlignmentInstance
                    )) ?
                    ___CreateDirectrixDerivedReferenceSweptAreaSolid(
                            model,
                            ___GetProductRepresentationItem(
                                    ifcAlignmentInstance
                                ),
                            ifcProfileInstance
                        ) :
                    ___CreateFixedReferenceSweptAreaSolid(
                            model,
                            ___GetProductRepresentationItem(
                                    ifcAlignmentInstance
                                ),
                            ifcProfileInstance
                        );

    sdaiPutAttrBN(
            ifcProductInstance,
            "Representation",
            sdaiINSTANCE,
            (void*) ___CreateProductDefinitionShape(
                            model,
                            ifcFixedReferenceSweptAreaSolidInstance
                        )
        );

    return  ifcFixedReferenceSweptAreaSolidInstance;
}

static  inline  int_t    AlignmentGenerateSweep(
                                int_t   model,
                                int_t   ifcAlignmentInstance,
                                int_t   ifcProfileInstance,
                                int_t   ifcProductInstance,
                                double  gauge
                            )
{
    int_t   ifcCompositeProfileDefInstance, * aggrProfiles;
        
    ifcCompositeProfileDefInstance = sdaiCreateInstanceBN(model, "IFCCOMPOSITEPROFILEDEF");
 
    aggrProfiles = sdaiCreateAggrBN(ifcCompositeProfileDefInstance, "Profiles");

    sdaiAppend((int_t) aggrProfiles, sdaiINSTANCE, (void*) ___CreateDerivedProfileDef(model, ifcProfileInstance, -(gauge / 2.)));
    sdaiAppend((int_t) aggrProfiles, sdaiINSTANCE, (void*) ___CreateDerivedProfileDef(model, ifcProfileInstance, gauge / 2.));

    return  AlignmentGenerateSweep(
                    model,
                    ifcAlignmentInstance,
                    ifcCompositeProfileDefInstance,
                    ifcProductInstance
                );
}