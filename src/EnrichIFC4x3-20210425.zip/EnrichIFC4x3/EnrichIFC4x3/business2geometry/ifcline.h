#pragma once


#include "ifccartesianpoint.h"
#include "ifcvector.h"


static	inline	int_t   ___CreateLine(
                                int_t       model
                            )
{
    int_t	ifcLineInstance = sdaiCreateInstanceBN(model, (char*) "IFCLINE");

    sdaiPutAttrBN(ifcLineInstance, "Pnt", sdaiINSTANCE, (void*) ___CreateCartesianPoint2D(model));
    sdaiPutAttrBN(ifcLineInstance, "Dir", sdaiINSTANCE, (void*) ___CreateVector(model));

    assert(ifcLineInstance);

    return	ifcLineInstance;
}

static	inline	int_t   ___CreateLine(
                                int_t       model,
                                ___VECTOR2  * orientation
                            )
{
    int_t	ifcLineInstance = sdaiCreateInstanceBN(model, (char*) "IFCLINE");

    sdaiPutAttrBN(ifcLineInstance, "Pnt", sdaiINSTANCE, (void*) ___CreateCartesianPoint2D(model));
    sdaiPutAttrBN(ifcLineInstance, "Dir", sdaiINSTANCE, (void*) ___CreateVector(model, orientation));

    assert(ifcLineInstance);

    return	ifcLineInstance;
}
