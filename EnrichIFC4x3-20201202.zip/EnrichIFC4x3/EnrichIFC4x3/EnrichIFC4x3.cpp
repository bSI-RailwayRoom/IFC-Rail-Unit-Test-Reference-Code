// EnrichIFC4x3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <assert.h>

#include "./ifcengine/include/ifcengine.h"
#include "./ifcengine/include/engine.h"

#include "./business2geometry/ifcalignment.h"


static  const   uint64_t    flagbit0 = 1;                           // 2^^0                          0000.0000..0000.0001
static  const   uint64_t    flagbit1 = 2;                           // 2^^1                          0000.0000..0000.0010
static  const   uint64_t    flagbit2 = 4;                           // 2^^2                          0000.0000..0000.0100
static  const   uint64_t    flagbit3 = 8;                           // 2^^3                          0000.0000..0000.1000

static  const   uint64_t    flagbit4 = 16;                          // 2^^4                          0000.0000..0001.0000
static  const   uint64_t    flagbit5 = 32;                          // 2^^5                          0000.0000..0010.0000
static  const   uint64_t    flagbit6 = 64;                          // 2^^6                          0000.0000..0100.0000
static  const   uint64_t    flagbit7 = 128;                         // 2^^7                          0000.0000..1000.0000

static  const   uint64_t    flagbit8 = 256;                         // 2^^8                          0000.0001..0000.0000
static  const   uint64_t    flagbit9 = 512;                         // 2^^9                          0000.0010..0000.0000
static  const   uint64_t    flagbit10 = 1024;                       // 2^^10                         0000.0100..0000.0000
static  const   uint64_t    flagbit11 = 2048;                       // 2^^11                         0000.1000..0000.0000

static  const   uint64_t    flagbit12 = 4096;                       // 2^^12                         0001.0000..0000.0000
static  const   uint64_t    flagbit13 = 8192;                       // 2^^13                         0010.0000..0000.0000
static  const   uint64_t    flagbit14 = 16384;                      // 2^^14                         0100.0000..0000.0000
static  const   uint64_t    flagbit15 = 32768;                      // 2^^15                         1000.0000..0000.0000

int main()
{
//    int_t   ifcModel = sdaiOpenModelBN(0, "c:\\project\\UT_AWC_2_LandXML offcamber.txt.ifc", "");
    int_t   ifcModel = sdaiOpenModelBN(0, "c:\\project\\input.ifc", "");

    if (ifcModel) {
        int_t   * ifcAlignmentInstances = sdaiGetEntityExtentBN(ifcModel, "IFCALIGNMENT"),
                noIfcAlignmentInstances = sdaiGetMemberCount(ifcAlignmentInstances);
        if (noIfcAlignmentInstances) {
            std::cout << noIfcAlignmentInstances << " alignment instances found.\n";

            for (int_t i = 0; i < noIfcAlignmentInstances; i++) {
                int_t   ifcAlignmentInstance = 0;
                engiGetAggrElement(ifcAlignmentInstances, i, sdaiINSTANCE, &ifcAlignmentInstance);

                std::cout << "Alignment instance " << i << ":\n";

                int_t   ifcProductRepresentationInstance = 0;
                sdaiGetAttrBN(ifcAlignmentInstance, "Representation", sdaiINSTANCE, &ifcProductRepresentationInstance);

                if (ifcProductRepresentationInstance) {
                    std::cout << "  Already has geometry definition, stop processing for this instance.\n";
                }
                else {
                    std::cout << "  Start processing.\n";

                    AlignmentGenerateGeometry(
                            ifcModel,
                            ifcAlignmentInstance
                        );
                }
            }
        }
        else {
            std::cout << "No alignment instances found.\n";
        }

        sdaiSaveModelBN(ifcModel, "c:\\project\\enriched.ifc");
        sdaiCloseModel(ifcModel);
    }

    ifcModel = sdaiOpenModelBN(0, "c:\\project\\enriched.ifc", "");

    {
        int64_t owlModel = 0;
        owlGetModel(ifcModel, &owlModel);
        int64_t mask = GetFormat(0, 0),
                setting = flagbit2 + flagbit4 + flagbit9;
        SetFormat(owlModel, setting, mask);

        int_t   * ifcCompositeCurveInstances = sdaiGetEntityExtentBN(ifcModel, "IFCCOMPOSITECURVE"),
                noIfcCompositeCurveInstances = sdaiGetMemberCount(ifcCompositeCurveInstances);
        for (int_t i = 0; i < noIfcCompositeCurveInstances; i++) {
            int_t   ifcCompositeCurveInstance = 0;
            engiGetAggrElement(ifcCompositeCurveInstances, i, sdaiINSTANCE, &ifcCompositeCurveInstance);
            
            int_t   * ifcSegmentInstances = nullptr;
            sdaiGetAttrBN(ifcCompositeCurveInstance, "Segments", sdaiAGGR, &ifcSegmentInstances);
            int_t   noIfcSegmentInstances = sdaiGetMemberCount(ifcSegmentInstances);

            VECTOR3 * pStartPoint = new VECTOR3[noIfcSegmentInstances];
            VECTOR3 * pStartVector = new VECTOR3[noIfcSegmentInstances];
            VECTOR3 * pEndPoint = new VECTOR3[noIfcSegmentInstances];
            VECTOR3 * pEndVector = new VECTOR3[noIfcSegmentInstances];

            for (int_t j = 0; j < noIfcSegmentInstances; j++) {
                int_t   ifcSegmentInstance = 0;
                engiGetAggrElement(ifcSegmentInstances, j, sdaiINSTANCE, &ifcSegmentInstance);

                int64_t owlInstance = 0;
                owlBuildInstance(ifcModel, ifcSegmentInstance, &owlInstance);

                int64_t vertexBufferSize = 0, indexBufferSize = 0;
                CalculateInstance(owlInstance, &vertexBufferSize, &indexBufferSize, nullptr);
                if (vertexBufferSize && indexBufferSize) {
                    double  * vertices = new double[3 * vertexBufferSize];
                    UpdateInstanceVertexBuffer(owlInstance, vertices);

                    int32_t * indices = new int32_t[indexBufferSize];
                    UpdateInstanceIndexBuffer(owlInstance, indices);

                    VECTOR3 * pPnt = new VECTOR3[indexBufferSize];

                    int_t    offset = 0;
                    int64_t  conceptualFaceCnt = GetConceptualFaceCnt(owlInstance);
                    for (int_t k = 0; k < conceptualFaceCnt; k++) {
                        int64_t  startIndicesLines = 0, noIndicesLines = 0;
                        GetConceptualFaceEx(
                                owlInstance, k,
                                nullptr, nullptr,
                                &startIndicesLines, &noIndicesLines,
                                nullptr, nullptr,
                                nullptr, nullptr,
                                nullptr, nullptr
                            );
                        assert(noIndicesLines);

                        if (offset) {
                            assert(pPnt[offset - 1].x == vertices[3 * indices[startIndicesLines] + 0]);
                            assert(pPnt[offset - 1].y == vertices[3 * indices[startIndicesLines] + 1]);
                            assert(pPnt[offset - 1].z == vertices[3 * indices[startIndicesLines] + 2]);
                            offset--;
                        }

                        for (int_t m = 0; m < noIndicesLines; m++) {
                            pPnt[offset].x = vertices[3 * indices[startIndicesLines + m] + 0];
                            pPnt[offset].y = vertices[3 * indices[startIndicesLines + m] + 1];
                            pPnt[offset].z = vertices[3 * indices[startIndicesLines + m] + 2];
                            offset++;
                        }
                    }
                    assert(offset >= 2);

                    VECTOR3 * pnt0 = &pPnt[0],
                            * pnt1 = &pPnt[1],
                            * pntNm2 = &pPnt[offset - 2],
                            * pntNm1 = &pPnt[offset - 1];
                    pStartPoint[j].x = pnt0->x;
                    pStartPoint[j].y = pnt0->y;
                    pStartPoint[j].z = pnt0->z;
                    Vec3Subtract(&pStartVector[j], pnt1, pnt0);
                    Vec3Normalize(&pStartVector[j]);
                    pEndPoint[j].x = pntNm1->x;
                    pEndPoint[j].y = pntNm1->y;
                    pEndPoint[j].z = pntNm1->z;
                    Vec3Subtract(&pEndVector[j], pntNm1, pntNm2);
                    Vec3Normalize(&pEndVector[j]);
                }
                else {
                    assert(false);
                }
            }

            std::cout << "IfcCompositeCurve.\n";

            if (noIfcSegmentInstances) {
                int_t   ifcCompositeCurveInstance = 0;
                engiGetAggrElement(ifcCompositeCurveInstances, i, sdaiINSTANCE, &ifcCompositeCurveInstance);

                for (int_t j = 1; j < noIfcSegmentInstances; j++) {
                    VECTOR3 vecDiff;
                    Vec3Subtract(&vecDiff, &pEndPoint[j - 1], &pStartPoint[j]);
                    double  distance = Vec3Length(&vecDiff);
                    double  dotProduct = Vec3Dot(&pEndVector[j - 1], &pStartVector[j]);
                    std::cout << "  distance: " << distance << ", dotProduct: " << dotProduct << ".\n";

                    assert(std::fabs(distance) <= 0.001);
                    assert(dotProduct >= 0.999 && dotProduct <= 1.0000000001);
                }
            }
        }

        sdaiCloseModel(ifcModel);
    }

    std::cout << "Ready!\n";
}
