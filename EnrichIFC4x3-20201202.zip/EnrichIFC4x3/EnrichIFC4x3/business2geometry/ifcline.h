#pragma once

#include "ifccartesianpoint.h"
#include "ifcvector.h"


static	inline	int_t   CreateLine(
                                int_t   model
                            )
{
    int_t	ifcLineInstance = sdaiCreateInstanceBN(model, (char*) "IFCLINE");

    VECTOR2 pnt = { 0., 0. };
    sdaiPutAttrBN(ifcLineInstance, "Pnt", sdaiINSTANCE, (void*) CreateCartesianPoint2D(model, &pnt));
    sdaiPutAttrBN(ifcLineInstance, "Dir", sdaiINSTANCE, (void*) CreateVector(model));

    assert(ifcLineInstance);

    return	ifcLineInstance;
}
