#pragma once

#include "clothoid.h"
#include "ifcaxis2placement2d.h"


int_t   CreateClothoid(
                int_t   model,
                double  startRadiusOfCurvature,
                double  endRadiusOfCurvature,
                double  segmentLength,
                int_t   ifcCurveSegmentInstance,
                double  * pSegmentLength
            )
{
    int_t	ifcClothoidInstance = sdaiCreateInstanceBN(model, (char*) "IFCCLOTHOID");

    MATRIX  matrix;
    MatrixIdentity(&matrix);

    double  A, offset;

    if (startRadiusOfCurvature == 0.) {
        assert(endRadiusOfCurvature);
        A = std::sqrt(std::fabs(endRadiusOfCurvature) * segmentLength);
        if (endRadiusOfCurvature < 0) { A = -A; }

        offset = 0.;
    }
    else if (endRadiusOfCurvature == 0.) {
        A = std::sqrt(std::fabs(startRadiusOfCurvature) * segmentLength);
        if (startRadiusOfCurvature > 0) { A = -A; }

        offset = -segmentLength;

        CalculateClothoidDirection(
                -A,
                -offset,
                (VECTOR3*) &matrix._11
            );
    }
    else if (startRadiusOfCurvature < 0. && endRadiusOfCurvature < 0.) {
        if (startRadiusOfCurvature < endRadiusOfCurvature) {
            //  Calculate clothoidConstant
            //      endRadius * (len + offset) = startRadius * offset
            //      startRadius * offset - endRadius * offset = endRadius * len
            //      offset = (endRadius * len) / (startRadius - endRadius)
            double  offsetLength = (endRadiusOfCurvature * segmentLength) / (startRadiusOfCurvature - endRadiusOfCurvature);
            A = std::sqrt(std::fabs(endRadiusOfCurvature) * (segmentLength + offsetLength));
            assert(A == std::sqrt(std::fabs(startRadiusOfCurvature) * offsetLength));

            A = -A;
            (*pSegmentLength) = -(*pSegmentLength);

            offset = -offsetLength;

            CalculateClothoidDirection(
                    -A,
                    -offset,
                    (VECTOR3*) &matrix._11
                );

            matrix._11 = -matrix._11;
            matrix._12 = -matrix._12;
            assert(matrix._13 == 0.);
        }
        else {
            assert(startRadiusOfCurvature > endRadiusOfCurvature);
            //  Calculate clothoidConstant
            //      startRadius * (len + offset) = endRadius * offset
            //      endRadius * offset - startRadius * offset = startRadius * len
            //      offset = (startRadius * len) / (endRadius - startRadius)
            double  offsetLength = (startRadiusOfCurvature * segmentLength) / (endRadiusOfCurvature - startRadiusOfCurvature);
            A = std::sqrt(std::fabs(startRadiusOfCurvature) * (segmentLength + offsetLength));
            assert(A == std::sqrt(std::fabs(endRadiusOfCurvature) * offsetLength));

            offset = -(segmentLength + offsetLength);

            CalculateClothoidDirection(
                    -A,
                    -offset,
                    (VECTOR3*) &matrix._11
                );
        }
    }
    else if (startRadiusOfCurvature > 0. && endRadiusOfCurvature > 0.) {
        if (startRadiusOfCurvature < endRadiusOfCurvature) {
            //  Calculate clothoidConstant
            //      startRadius * (len + offset) = endRadius * offset
            //      endRadius * offset - startRadius * offset = startRadius * len
            //      offset = (startRadius * len) / (endRadius - startRadius)
            double  offsetLength = (startRadiusOfCurvature * segmentLength) / (endRadiusOfCurvature - startRadiusOfCurvature);
            A = std::sqrt(std::fabs(startRadiusOfCurvature) * (segmentLength + offsetLength));
            assert(A == std::sqrt(std::fabs(endRadiusOfCurvature) * offsetLength));

            A = -A;
            (*pSegmentLength) = -(*pSegmentLength);

            offset = -offsetLength;

            CalculateClothoidDirection(
                    -A,
                    -offset,
                    (VECTOR3*) &matrix._11
                );

            matrix._11 = -matrix._11;
            matrix._12 = -matrix._12;
            assert(matrix._13 == 0.);
        }
        else {
            assert(startRadiusOfCurvature > endRadiusOfCurvature);
            //  Calculate clothoidConstant
            //      endRadius * (len + offset) = startRadius * offset
            //      startRadius * offset - endRadius * offset = endRadius * len
            //      offset = (endRadius * len) / (startRadius - endRadius)
            double  offsetLength = (endRadiusOfCurvature * segmentLength) / (startRadiusOfCurvature - endRadiusOfCurvature);
            A = std::sqrt(std::fabs(endRadiusOfCurvature) * (segmentLength + offsetLength));
            assert(A == std::sqrt(std::fabs(startRadiusOfCurvature) * offsetLength));

            offset = -(segmentLength + offsetLength);

            CalculateClothoidDirection(
                    -A,
                    -offset,
                    (VECTOR3*) &matrix._11
                );
        }
    }
    else {
        assert(false);
        A = 1.;
        offset = 0.;
    }

    if (offset) {
        Vec3Cross((VECTOR3*) &matrix._21, (VECTOR3*) &matrix._31, (VECTOR3*) &matrix._11);

        VECTOR3 pos;
        CalculateClothoidPosition(
                A,
                -offset,
                (VECTOR3*) &pos
            );

        Vec3Transform((VECTOR3*) &matrix._41, (VECTOR3*) &pos, &matrix);

        void   * segmentStartADB = sdaiCreateADB(sdaiREAL, &offset);
        sdaiPutADBTypePath(segmentStartADB, 1, "IFCPARAMETERVALUE");
        sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentStart", sdaiADB, (void*) segmentStartADB);
    }
    else {
        void   * segmentStartADB = sdaiCreateADB(sdaiREAL, &offset);
        sdaiPutADBTypePath(segmentStartADB, 1, "IFCNONNEGATIVELENGTHMEASURE");
        sdaiPutAttrBN(ifcCurveSegmentInstance, "SegmentStart", sdaiADB, (void*) segmentStartADB);
    }

    sdaiPutAttrBN(ifcClothoidInstance, "Position", sdaiINSTANCE, (void*) CreateAxis2Placement2D(model, &matrix));

    sdaiPutAttrBN(ifcClothoidInstance, "ClothoidConstant", sdaiREAL, &A);

    assert(ifcClothoidInstance);

    return	ifcClothoidInstance;
}
