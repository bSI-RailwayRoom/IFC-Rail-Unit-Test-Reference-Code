// alignmentconsistency.cpp : Defines the initialization routines for the DLL.
//

#include "alignmentconsistencyfile.h"


int_t	CheckConsistencyFile__internal(
				int_t	model
			)
{
//	if (model == 0) {
//		assert__error(enum_error::MODEL_ZERO);
//	}

	return	0;
}