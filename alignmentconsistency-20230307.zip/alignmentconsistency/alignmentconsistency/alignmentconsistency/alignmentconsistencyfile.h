// alignmentconsistency.h : main header file for the alignmentconsistency DLL
//

#pragma once

#include "issues.h"


int_t	CheckConsistencyFile__internal(
				int_t	model
			);