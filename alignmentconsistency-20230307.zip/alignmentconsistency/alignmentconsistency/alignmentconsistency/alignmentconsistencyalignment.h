// alignmentconsistency.h : main header file for the alignmentconsistency DLL
//

#pragma once

#include "issues.h"


int_t	CheckConsistencyAlignment__internal(
				int_t	model,
				double	epsilon
			);